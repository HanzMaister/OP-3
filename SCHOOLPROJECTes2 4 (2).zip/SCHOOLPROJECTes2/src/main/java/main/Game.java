package main;
 public class Game implements Runnable {




    int fps = 60;
    Thread gamethread;
    GamePanel gamePanel;
    GameLogic logic;


    public void startGameThread(){
        gamethread = new Thread(this);
        gamethread.start();
    }
    @Override
    public void run() {
        double drawInterval = 1000000000/fps;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        while (gamethread != null){
            currentTime = System.nanoTime();

            delta += (currentTime - lastTime)/drawInterval;
            lastTime = currentTime;

            if(delta >= 1){
                logic.update();
                gamePanel.repaint();
                delta--;
            }
        }
    }
}
