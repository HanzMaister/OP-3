package main;

import objects.Bullet;
import objects.Enemy;
import objects.Player;

import javax.swing.*;
import java.nio.Buffer;
import java.util.ArrayList;

public class GameLogic {
    private Player player;
    private ArrayList<Enemy> enemies;
    private ArrayList<Enemy>enemiesToRemove;
    private ArrayList<Bullet>bullets;
    private ArrayList<Bullet>bulletsToRemove;
    KeyReader keyReader = new KeyReader();
    GamePanel gamePanel = new GamePanel();
    private int enemyCount = 0;
    private int fireCount = 0;
    private boolean fired = false;
    private boolean isPlayerColided = false;
    int killCount = 0;
    int cash = 0;
    // TO REMOVE LATER!!!
    GameFrame frame;
    public GameLogic(){
        this.player = new Player(gamePanel,keyReader);
        this.enemies = new ArrayList<>();
        this.enemiesToRemove = new ArrayList<>();
        this.bullets = new ArrayList<>();
        this.bulletsToRemove = new ArrayList<>();
    }
    public void initializeEnemy(){
        enemies.add(new Enemy(gamePanel));
        enemyCount++;
    }
    public void bulletShoot(){
        if(keyReader.shoot == true){
            fireCount++;
            if(fireCount != 0 || fireCount == 10){
                fired = false;
            }
            if(fireCount == 1 ){
                fired = true;
            }
            if(fireCount > 10){
                fireCount = 0;
            }
        }
        else {
            fireCount = 0;
        }
    }
    public void initializeBullet(){
        bulletShoot();
        if(fired == true) {
            bullets.add(new Bullet(gamePanel,player.x + 24,player.y));
        }
    }
    public void checkCollision(){
        for (Enemy enemy : enemies){
            if(player.solidRect.intersects(enemy.rectangle)){
                isPlayerColided = true;
            }
            // MOVE TO GRAPHICS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            if(isPlayerColided == true){
                JOptionPane.showMessageDialog(frame, "you lost");
                frame.getDefaultCloseOperation();
            }
        }
        for (Bullet bullet:bullets){
            for(Enemy enemy : enemies){
                if(bullet.rectangle.intersects(enemy.rectangle)){
                    if(enemy.getHp()<1){
                        killCount++;
                        System.out.println("You killed " + killCount);
                        cash = cash + 20;
                        System.out.println("cash: $" + cash);
                        enemiesToRemove.add(enemy);
                        bulletsToRemove.add(bullet);

                    }
                    else {
                        bulletsToRemove.add(bullet);
                        enemy.setHp(enemy.getHp() - 1);
                    }
                }
            }
        }
    }
    public void update(){
        player.update();
        for(Enemy enemy:enemies){
            enemy.updatePosition();
        }
        for(Bullet bullet: bullets){
            bullet.update();
        }

    }
}
