package main;

import objects.BackGround;
import objects.Bullet;
import objects.Enemy;
import objects.Player;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GamePanel extends JPanel implements Runnable{


    public int width = 600, height = 800;
    GameFrame frame;
    KeyReader keyReader = new KeyReader();
    Player player = new Player(this, keyReader);
    ArrayList<Enemy> enemies;
    ArrayList<Enemy> enemiesToRemove;
    ArrayList<Bullet> bullets;
    ArrayList<Bullet>bulletsToRemove;

    BackGround backGround;
    public int enemycount = 0;
    Thread gamethread;
    public boolean isPlayerColided = false;
    int fps = 60;

    // loop variables
    double drawInterval = 1000000000/fps;
    double delta = 0;
    long lastTime = System.nanoTime();
    long currentTime;
    // spawn variables
    int startCount;
    int spawnRate = 60;
    public boolean fired = false;
    public int fireCount = 0;
    public int killCount = 0;
    public int cash = 0;
    private Font font = new Font("Aptos", Font.BOLD,22 );
    boolean isLoaded = true;
    public int gameState = 1;

    public GamePanel(){
        setPreferredSize(new Dimension(width, height));
        setBackground(Color.black);
        setDoubleBuffered(true);
        backGround = new BackGround(this);
        enemies = new ArrayList<>();
        enemiesToRemove = new ArrayList<>();
        bullets = new ArrayList<>();
        bulletsToRemove = new ArrayList<>();
        addKeyListener(keyReader);
        setFocusable(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if(gameState == 2){

            backGround.draw(g);
            player.draw(g);
            g.setFont(font);
            g.setColor(Color.WHITE);
            g.drawString("Cash: $"+ Integer.toString(cash),450,80);
            g.drawString("You killed: " + Integer.toString(killCount), 450, 50);

            for (Enemy enemy : enemies){
                enemy.draw(g);
            }
            for(Bullet bullet : bullets){
                bullet.draw(g);
            }
        }
        else{
            backGround.draw(g);
            g.setFont(font);
            g.setColor(Color.WHITE);
            g.drawString("PRESS ENTER TO START GAME ", 160,400);

            setLayout();
        }
    }

    public void setLayout(){
        JButton startButton = new JButton("START");
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

    }
    public void changeGameState(){
        if(keyReader.changeState == true){
            gameState = 2;
        }
    }
    public void update(){
        changeGameState();
        if(gameState == 2){
            player.update();
            for(Bullet bullet : bullets){
                bullet.update();
            }
            for (Enemy enemy : enemies){
                enemy.updatePosition();
            }
            checkCollision();
            spawnInterval();
            deleteEnemy();
            deleteBullet();
            initializeBullet();
            increaseLevel();

        }

    }
    public void increaseLevel(){
        if(killCount > 5 && killCount < 30){
            for(Enemy enemy:enemies){
                if(enemy.getLevel() < 2){
                    enemy.setHp(6);
                }
            }
        }
    }
    public void initializeEnemy(){
        enemies.add(new Enemy(this));
        enemycount++;
        System.out.println(enemycount);
    }
    public void deleteEnemy(){
        for (Enemy enemy : enemies){
            if (enemy.y > height){
                enemiesToRemove.add(enemy);
            }
        }
        enemies.removeAll(enemiesToRemove);
    }
    public void deleteBullet(){
        for(Bullet bullet : bullets){
            if(bullet.y < 1){
                bulletsToRemove.add(bullet);
            }
        }
        bullets.removeAll(bulletsToRemove);
    }
    public void bulletShoot(){
        if(keyReader.shoot == true){
            fireCount++;
            if(fireCount != 0 || fireCount == 10){
                fired = false;
            }
            if(fireCount == 1 ){
                fired = true;

            }
            if(fireCount > 10){
                fireCount = 0;
            }
        }
        else {
            fireCount = 0;
        }


    }
    public void initializeBullet(){
        bulletShoot();
        if(fired == true) {
            bullets.add(new Bullet(this,player.x + 24,player.y));
        }
    }


    public void checkCollision(){
        for (Enemy enemy : enemies){
            if(player.solidRect.intersects(enemy.rectangle)){
                isPlayerColided = true;
            }
            if(isPlayerColided == true){
                JOptionPane.showMessageDialog(frame, "you lost");
                frame.getDefaultCloseOperation();
            }
        }
        for (Bullet bullet:bullets){
            for(Enemy enemy : enemies){
                if(bullet.rectangle.intersects(enemy.rectangle)){
                    if(enemy.getHp()<1){
                        killCount++;
                        System.out.println("You killed " + killCount);
                        cash = cash + 20;
                        System.out.println("cash: $" + cash);
                        enemiesToRemove.add(enemy);
                        bulletsToRemove.add(bullet);

                    }
                    else {
                        bulletsToRemove.add(bullet);
                        enemy.setHp(enemy.getHp() - 1);
                    }
                    }
                }
            }
    }
    public void spawnInterval(){
        startCount ++;
        if(startCount == spawnRate){
            initializeEnemy();
            startCount = 0;
        }
    }
    public void startGameThread(){
        gamethread = new Thread(this);
        gamethread.start();
    }
    @Override
    public void run() {

        while (gamethread != null){
            currentTime = System.nanoTime();

            delta += (currentTime - lastTime)/drawInterval;
            lastTime = currentTime;

            if(delta >= 1){
                update();
                repaint();
                delta--;
            }
        }
    }
}
