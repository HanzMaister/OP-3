package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyReader implements KeyListener {
    public boolean uPressed, downPressed, leftPressed, rightPressed,shoot,reload, changeState;
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_W){
            uPressed = true;
        }
        else if(e.getKeyCode() == KeyEvent.VK_S){
            downPressed = true;
        }
        else if(e.getKeyCode() == KeyEvent.VK_A){
            leftPressed = true;
        }
        else if(e.getKeyCode() == KeyEvent.VK_D){
            rightPressed = true;
        }
        else if(e.getKeyCode() == KeyEvent.VK_SPACE){
            shoot = true;
        }
        else if(e.getKeyCode() == KeyEvent.VK_R){
            reload = true;
        }
        else if (e.getKeyCode() == KeyEvent.VK_ENTER){
            changeState = true;
        }


    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_W){
            uPressed = false;
        }
        else if(e.getKeyCode() == KeyEvent.VK_S){
            downPressed = false;
        }
        else if(e.getKeyCode() == KeyEvent.VK_A){
            leftPressed = false;
        }
        else if(e.getKeyCode() == KeyEvent.VK_D){
            rightPressed = false;
        }
        else if(e.getKeyCode() == KeyEvent.VK_SPACE){
            shoot = false;
        }
        else if(e.getKeyCode() == KeyEvent.VK_R){
            reload = false;
        }
    }
}
