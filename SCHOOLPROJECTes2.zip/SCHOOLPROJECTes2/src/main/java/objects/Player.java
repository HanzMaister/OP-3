package objects;

import main.Game;
import main.KeyReader;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Player {
    public int x;
    public int y;
    public int width = 64;
    public int height = 64;
    public int defaultSpeed = 6;
    public int speed;


    public int hp = 3;
    int level = 1;
    public Rectangle solidRect;
    KeyReader keyReader;

    public Player(KeyReader keyReader){
        this.keyReader = keyReader;
        setDefaultValues();
    }

    public void setDefaultValues(){
        x = 250;
        y = 550;
        hp = 3;
        speed = level * defaultSpeed;
    }
    public void update(){
        if(keyReader.uPressed) {
            y -= speed;
        }
        if(keyReader.downPressed) {
            y += speed;
        }
        if(keyReader.leftPressed){
            x -= speed;
        }
        if(keyReader.rightPressed){
            x += speed;
        }
        solidRect = new Rectangle(x + 20, y + 20,  width -40, height - 10 );
    }


    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getSpeed() {
        return speed;
    }


    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

}
