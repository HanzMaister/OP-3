package objects;

import main.Game;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Shop {
    Game keyReader;
    BufferedImage product1,product2,product3,product4;
    int x = 0;
    int y = 0;
    int width = 128;
    int height = 128;
    Rectangle solid1, solid2, solid3, solid4;
    public boolean buyed1, buyed2, buyed3, buyed4;
    public int buy = 0;
    public Shop(){
        setDefaultValues();
        loadShopLayout();
    }
    public void setDefaultValues(){
        solid1 = new Rectangle(100, 100, width, height);
        solid2 = new Rectangle(356, 100, width, height);
        solid3 = new Rectangle(100, 356, width, height);
        solid4 = new Rectangle(356, 356, width, height);
    }
    public void loadShopLayout(){
        try {
            product1 = ImageIO.read(getClass().getResourceAsStream("/object/bullet.png"));
            product2 = ImageIO.read(getClass().getResourceAsStream("/object/rocket2.png"));
            product3 = ImageIO.read(getClass().getResourceAsStream("/object/bullet3.png"));
            product4 = ImageIO.read(getClass().getResourceAsStream("/object/shopM.png"));

        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void draw(Graphics g){
        g.fillRect(100, 100, width,height);
        g.fillRect(356, 100, width,height);
        g.fillRect(100, 356, width,height);
        g.fillRect(356, 356, width,height);
        g.drawImage(product1,  100, 100, width,height, null);
        g.drawImage(product2,  356, 100, width,height, null);
        g.drawImage(product3,  100, 356, width,height, null);
        g.drawImage(product4,  356, 356, width,height, null);
    }

    public Rectangle getSolid1() {
        return solid1;
    }

    public Rectangle getSolid2() {
        return solid2;
    }

    public Rectangle getSolid3() {
        return solid3;
    }

    public Rectangle getSolid4() {
        return solid4;
    }

    public int getBuy() {
        return buy;
    }

    public void setBuy(int buy) {
        this.buy = buy;
    }
}
