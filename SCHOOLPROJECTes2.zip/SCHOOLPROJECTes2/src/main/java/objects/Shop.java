package objects;

import main.Game;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Shop {
    int width = 128;
    int height = 128;
    Rectangle solid1, solid2;
    public boolean buyed1, buyed2;
    public Shop(){
        setDefaultValues();
    }
    public void setDefaultValues(){
        solid1 = new Rectangle(100, 100, width, height);
        solid2 = new Rectangle(356, 100, width, height);
    }

    public Rectangle getSolid1() {
        return solid1;
    }
    public Rectangle getSolid2() {
        return solid2;
    }


    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}
