package objects;

import main.Game;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Shop {
    BufferedImage product1,product2,product3,product4;
    int width = 128;
    int height = 128;
    Rectangle solid1, solid2;
    public boolean buyed1, buyed2;
    public int buy = 0;
    public Shop(){
        setDefaultValues();
        loadShopLayout();
    }
    public void setDefaultValues(){
        solid1 = new Rectangle(100, 100, width, height);
        solid2 = new Rectangle(356, 100, width, height);
    }
    public void loadShopLayout(){
        try {
            product1 = ImageIO.read(getClass().getResource("/bullet.png"));
            product2 = ImageIO.read(getClass().getResource("/rocket2.png"));
            product3 = ImageIO.read(getClass().getResource("/bullet3.png"));
            product4 = ImageIO.read(getClass().getResource("/shopM.png"));

        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void draw(Graphics g){
        g.fillRect(100, 100, width,height);
        g.fillRect(356, 100, width,height);
        g.drawImage(product1,  100, 100, width,height, null);
        g.drawImage(product2,  356, 100, width,height, null);

    }

    public Rectangle getSolid1() {
        return solid1;
    }
    public Rectangle getSolid2() {
        return solid2;
    }
    public int getBuy() {
        return buy;
    }
    public void setBuy(int buy) {
        this.buy = buy;
    }
}
