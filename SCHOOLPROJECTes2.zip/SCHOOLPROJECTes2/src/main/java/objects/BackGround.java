package objects;

import main.GameLogic;
import main.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class BackGround {
    GameLogic logic = new GameLogic();
    GamePanel gamePanel;
    BufferedImage image;
    int width = 800;
    int height = 800;

    public BackGround(GamePanel gamePanel){
        this.gamePanel = gamePanel;
        getImage();

    }
    public void getImage(){
        try {
            switch (logic.gameState){
                case 1:
                    image = ImageIO.read(getClass().getResource("/BCGearth.png"));
            }

        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void draw(Graphics g) {
        g.drawImage(image,0, 0, width, height, null);
    }
}
