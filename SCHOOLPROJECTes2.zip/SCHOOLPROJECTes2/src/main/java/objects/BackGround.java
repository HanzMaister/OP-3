package objects;

import main.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class BackGround {
    GamePanel gamePanel;
    BufferedImage image;
    int width = 800;
    int height = 800;

    public BackGround(GamePanel gamePanel){
        this.gamePanel = gamePanel;
        getImage();

    }
    public void getImage(){
        try {
            image = ImageIO.read(getClass().getResourceAsStream("/object/BCGearth.png"));

        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void draw(Graphics g) {
        g.drawImage(image,0, 0, width, height, null);
    }
}
