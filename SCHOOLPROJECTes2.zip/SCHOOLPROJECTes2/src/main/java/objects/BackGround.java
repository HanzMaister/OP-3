package objects;

import main.GameLogic;
import main.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class BackGround {
    GamePanel gamePanel;
    int x = 0;
    int y = 0;
    int width = 800;
    int height = 800;

    public BackGround(GamePanel gamePanel){
        this.gamePanel = gamePanel;

    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}
