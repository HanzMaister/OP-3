package objects;

import main.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Bullet {
    BufferedImage bullet1,bullet2, bullet3;
    public int x;
    public int y;
    public int width = 24;
    public int height = 24;
    public int speed = 12;
    public int level = 1;
    int caliber = 1;
    public Rectangle rectangle;

    public Bullet(int playerX, int playerY){
        this.x = playerX;
        this.y = playerY;
        setDefaultValues();
        getImage();
    }
    public void setDefaultValues(){
        level = 1;
        caliber = getCaliber();
    }
    public void update(){
        y -= speed;
        rectangle = new Rectangle(x,y,width,height);
    }
    public void getImage(){
        try {
            bullet1 = ImageIO.read(getClass().getResourceAsStream("/object/bullet1.png"));
            bullet2 = ImageIO.read(getClass().getResourceAsStream("/object/bullet.png"));
            bullet3 = ImageIO.read(getClass().getResourceAsStream("/object/bullet3.png"));

        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void draw(Graphics g){
        if(caliber == 2){
            g.drawImage(bullet2, x, y, width, height, null);
        }
        else if(caliber == 1){
            g.drawImage(bullet1, x, y, width, height, null);
        }
        else if(caliber == 3){
            g.drawImage(bullet3, x, y, width, height, null);
        }
    }
    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getCaliber() {
        return caliber;
    }

    public void setCaliber(int caliber) {
        this.caliber = caliber;
    }
}
