package objects;

import main.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Bullet {

    public int x;
    public int y;
    public int width = 24;
    public int height = 24;
    public int speed = 12;
    public int level = 1;
    int caliber = 1;
    public Rectangle rectangle;

    public Bullet(int playerX, int playerY){
        this.x = playerX;
        this.y = playerY;
        setDefaultValues();
    }
    public void setDefaultValues(){
        level = 1;
        caliber = getCaliber();
    }
    public void update(){
        y -= speed;
        rectangle = new Rectangle(x,y,width,height);
        System.out.println(caliber);
    }
    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
    public int getCaliber() {
        return caliber;
    }

    public void setCaliber(int caliber) {
        this.caliber = caliber;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

}
