package objects;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

public class Enemy {
    public int x;
    public int y;
    public int width = 64;
    public int height = 64;
    public int speed = 8;
    int level = 1;
    int hp = 1;
    public Rectangle rectangle;
    public Enemy(){
        setDefaultValues();
    }
    public void setDefaultValues(){
        Random random = new Random();
        x = random.nextInt(600);
        y = 0;
        level = getLevel();
        hp = getHp();

    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void updatePosition(){
        y += speed;
        rectangle = new Rectangle(x , y -20, width, height);
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

}
