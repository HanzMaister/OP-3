package main;

import javax.swing.*;

public class GameFrame extends JFrame {
    GameLogic logic;
    GamePanel gamePanel;
    Game game;
    public GameFrame(){
        logic = new GameLogic();
        gamePanel = new GamePanel(logic);
        game = new Game(gamePanel);
        setTitle("FAF");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        add(gamePanel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
