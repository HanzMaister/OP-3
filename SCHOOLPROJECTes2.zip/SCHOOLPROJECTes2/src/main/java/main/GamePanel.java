package main;

import objects.*;

import javax.swing.*;
import java.awt.*;


public class GamePanel extends JPanel{


    public int width = 600, height = 800;
    BackGround backGround;
    private Font font = new Font("Aptos", Font.BOLD,22 );
    GameLogic logic;

    public GamePanel(GameLogic logic){
        this.logic = logic;
        setPreferredSize(new Dimension(width, height));
        setBackground(Color.black);
        setDoubleBuffered(true);
        backGround = new BackGround(this);
        addKeyListener(logic.keyReader);
        addMouseListener(logic.keyReader);
        setFocusable(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if(logic.gameState == 2){

            backGround.draw(g);
            logic.player.draw(g);
            g.setFont(font);
            g.setColor(Color.WHITE);
            g.drawString("Cash: $"+ Integer.toString(logic.cash),450,80);
            g.drawString("You killed: " + Integer.toString(logic.killCount), 450, 50);


            for (Enemy enemy : logic.enemies){
                enemy.draw(g);
            }
            for(Bullet bullet : logic.bullets){
                bullet.draw(g);
            }
        }
        else if (logic.gameState == 1){
            backGround.draw(g);
            g.setFont(font);
            g.setColor(Color.WHITE);
            g.drawString("PRESS ENTER TO START GAME ", 160,400);
            g.drawString("Highest killcount: " + Integer.toString(logic.highKillCount), 160, 500 );
        }
        else if(logic.gameState == 3){
            logic.shop.draw(g);
        }
    }
}
