package main;

import objects.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;


public class GamePanel extends JPanel{


    public int width = 600, height = 800;
    BackGround backGround;
    private Font font = new Font("Aptos", Font.BOLD,22 );
    GameLogic logic;
    BufferedImage bullet1, bullet2, bullet3, enemyImage1, enemyImage2, enemyImage3, rocket1, rocket2, product1,product2,product3,product4, bcgImage;

    public GamePanel(GameLogic logic){
        this.logic = logic;
        setPreferredSize(new Dimension(width, height));
        setBackground(Color.black);
        setDoubleBuffered(true);
        backGround = new BackGround(this);
        addKeyListener(logic.keyReader);
        addMouseListener(logic.keyReader);
        setFocusable(true);
        getImage();
    }
    public void getImage(){
        try {
            bullet1 = ImageIO.read(getClass().getResource("/bullet1.png"));
            bullet2 = ImageIO.read(getClass().getResource("/bullet.png"));
            bullet3 = ImageIO.read(getClass().getResource("/bullet3.png"));
            enemyImage1 = ImageIO.read(getClass().getResource("/meteorite.png"));
            enemyImage2 = ImageIO.read(getClass().getResource("/meteorite2.png"));
            enemyImage3 = ImageIO.read(getClass().getResource("/meteorite3.png"));
            rocket1 = ImageIO.read(getClass().getResource("/Rocket.png"));
            rocket2 = ImageIO.read(getClass().getResource("/rocket2.png"));
            product1 = ImageIO.read(getClass().getResource("/bullet.png"));
            product2 = ImageIO.read(getClass().getResource("/rocket2.png"));
            product3 = ImageIO.read(getClass().getResource("/bullet3.png"));
            product4 = ImageIO.read(getClass().getResource("/shopM.png"));
            bcgImage = ImageIO.read(getClass().getResource("/BCGearth.png"));

        }catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if(logic.gameState == 2){

            g.drawImage(bcgImage,backGround.getX(),backGround.getY(),backGround.getWidth(),backGround.getHeight(),null);
            if(logic.player.getLevel() == 1){
                g.drawImage(rocket1,logic.player.getX(),logic.player.getY(),logic.player.getWidth(),logic.player.getHeight(), null);
            }
            if(logic.player.getLevel() == 2) {
                g.drawImage(rocket2, logic.player.getX(), logic.player.getY(), logic.player.getWidth(), logic.player.getHeight(), null);
            }
            g.setFont(font);
            g.setColor(Color.WHITE);
            g.drawString("Cash: $"+ Integer.toString(logic.cash),450,80);
            g.drawString("You killed: " + Integer.toString(logic.killCount), 450, 50);


            for (Enemy enemy : logic.enemies){
                if(enemy.getLevel() == 1){
                    g.drawImage(enemyImage1,enemy.getX(), enemy.getY(),enemy.getWidth(),enemy.getHeight(),null);
                }
                if(enemy.getLevel() == 2){
                    g.drawImage(enemyImage2,enemy.getX(), enemy.getY(),enemy.getWidth(),enemy.getHeight(),null);
                }
                if(enemy.getLevel() == 3){
                    g.drawImage(enemyImage3,enemy.getX(), enemy.getY(),enemy.getWidth(),enemy.getHeight(),null);
                }
            }
            for(Bullet bullet : logic.bullets){
                if(bullet.getCaliber() == 1){
                    g.drawImage(bullet1,bullet.getX(),bullet.getY(),bullet.getWidth(),bullet.getHeight(), null);
                }
                if(bullet.getCaliber() == 2){
                    g.drawImage(bullet2,bullet.getX(),bullet.getY(),bullet.getWidth(),bullet.getHeight(), null);
                }
            }
        }
        else if (logic.gameState == 1){
            g.drawImage(bcgImage,backGround.getX(),backGround.getY(),backGround.getWidth(),backGround.getHeight(),null);
            g.setFont(font);
            g.setColor(Color.WHITE);
            g.drawString("PRESS ENTER TO START GAME ", 160,400);
            g.drawString("Highest killcount: " + Integer.toString(logic.highKillCount), 160, 500 );
        }
        else if(logic.gameState == 3){
            g.fillRect(100, 100, logic.shop.getWidth(),logic.shop.getHeight());
            g.fillRect(356, 100, logic.shop.getWidth(),logic.shop.getHeight());
            g.drawImage(product1,  100, 100, logic.shop.getWidth(), logic.shop.getHeight(), null);
            g.drawImage(product2,  356, 100, logic.shop.getWidth(), logic.shop.getHeight(), null);
        }
    }
}
