package main;

public class Game implements Runnable{
    GamePanel panel;
    Thread thread;

    public boolean clicked = false;
    Game(GamePanel panel){
        this.panel = panel;

        thread = new Thread(this);
        thread.start();
    }

    @Override
    public void run() {
        int fps = 60;
        double drawInterval = 1000000000/fps;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;

        while (thread != null){
            currentTime = System.nanoTime();
            delta += (currentTime - lastTime)/drawInterval;
            lastTime = currentTime;

            if(delta >= 1){
                panel.logic.update();
                panel.repaint();
                delta--;
            }
        }
    }
}
