package main;

import objects.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GameLogic {
    public int width = 600, height = 800;
    GameFrame frame;
    Game keyReader = new Game();
    Player player = new Player(keyReader);
    Shop shop = new Shop();
    ArrayList<Enemy> enemies = new ArrayList<>();
    ArrayList<Enemy> enemiesToRemove = new ArrayList<>();
    ArrayList<Bullet> bullets = new ArrayList<>();
    ArrayList<Bullet>bulletsToRemove = new ArrayList<>();
    public int enemycount = 0;
    public boolean isPlayerColided = false;
    public boolean isGameOver = false;
    int startCount;
    int spawnRate = 60;
    public boolean fired = false;
    public int fireCount = 0;
    boolean timeForBulletUpgrade1 = false;
    public int killCount = 0;
    public int highKillCount = 0;
    public int cash = 0;
    public int gameState = 1;
    public int previousGameState;
    public GameLogic(){
    }
    public void setLayout(){
        JButton startButton = new JButton("START");
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }
    public void changeGameState(){
        if(gameState == 1){
            if(keyReader.changeState == true){
                gameState = 2;
                isGameOver = false;
            }
            if(isGameOver == true){
                enemies.removeAll(enemies);
                bullets.removeAll(bullets);
                enemies.removeAll(enemiesToRemove);
                bullets.removeAll(bulletsToRemove);
                killCount = 0;
            }
        }
        if(keyReader.enterShop == true && gameState == 2){
            previousGameState = gameState;
            gameState = 3;
            if(keyReader.enterShop == false){
            }
        }
    }

    public void update(){
        upgrade();
        changeGameState();
        if(gameState == 2){
            player.update();
            for(Bullet bullet : bullets){
                bullet.update();
            }
            for (Enemy enemy : enemies){
                enemy.updatePosition();
            }
            checkCollision();
            spawnInterval();
            deleteEnemy();
            deleteBullet();
            initializeBullet();
            increaseLevel();
            showHighKillCount();
        }
        if(gameState == 3){
            if(keyReader.enterShop == false){
                gameState = 2;
            }
        }
    }
    public void increaseLevel(){
        if(killCount > 2 && killCount < 12){
            for(Enemy enemy:enemies){
                if(enemy.getLevel() < 2){
                    enemy.setLevel(2);
                    enemy.setHp(enemy.getLevel() * 2);
                }
            }

        }
        if(killCount > 12){
            for(Enemy enemy:enemies){
                if(enemy.getLevel() < 3){
                    enemy.setLevel(3);
                    enemy.setHp(enemy.getLevel() * 3);
                }
            }

        }
    }
    public void upgrade(){
        if(keyReader.buy == 1 && cash - 20 > 0 && shop.buyed1 == false){
            System.out.println("koupil jsi 1");
            timeForBulletUpgrade1 = true;
            cash = cash -20;
            keyReader.buy = 0;
            shop.buyed1 = true;
        }
        if(keyReader.buy == 2 && shop.buyed2 == false){
            System.out.println("koupil jsi 2");
            if(player.getLevel() == 1){
                cash = cash - 40;
                player.setLevel(2);
                shop.buyed2 = true;
            }
            keyReader.buy = 0;
        }
        if(keyReader.buy == 3&&shop.buyed3 == false){
            for(Bullet bullet:bullets){
                bullet.setCaliber(3);
            }
            keyReader.buy = 0;
            shop.buyed3 = true;
            cash = cash - 40;
        }
        if(keyReader.buy == 4){
            System.out.println("koupil jsi 4");
            //DO ACTION
            keyReader.buy = 0;
        }
        else {
            keyReader.buy = 0;
        }
        upgradeBullet();
    }
    public void upgradeBullet(){
        if(timeForBulletUpgrade1 == true ){
            for(Bullet bullet:bullets){
                bullet.setCaliber(2);
            }
        }
    }
    public void initializeEnemy(){
        enemies.add(new Enemy());
        enemycount++;
    }
    public void deleteEnemy(){
        for (Enemy enemy : enemies){
            if (enemy.y > height){
                enemiesToRemove.add(enemy);
            }
        }
        enemies.removeAll(enemiesToRemove);
    }
    public void deleteBullet(){
        for(Bullet bullet : bullets){
            if(bullet.y < 1){
                bulletsToRemove.add(bullet);
            }
        }
        bullets.removeAll(bulletsToRemove);
    }
    public void bulletShoot(){
        if(keyReader.shoot == true){
            fireCount++;
            if(fireCount != 0 || fireCount == 10){
                fired = false;
            }
            if(fireCount == 1 ){
                fired = true;
            }
            if(fireCount > 10){
                fireCount = 0;
            }
        }
        else {
            fireCount = 0;
        }
    }
    public void initializeBullet(){
        bulletShoot();
        if(fired == true) {
            bullets.add(new Bullet(player.x + 24,player.y));
        }
    }
    public void checkCollision(){
        if(player.getX() < 0){
            player.setX(player.getX()+ player.getSpeed());
        }
        if(player.getX() > width - 64){
            player.setX(player.getX()-player.getSpeed());
        }
        if(player.getY() > height - 64){
            player.setY(player.getY() - player.getSpeed());
        }
        if(player.getY() < 256){
            player.setY(player.getY() + player.getSpeed());
        }
        for (Enemy enemy : enemies){
            if(player.solidRect.intersects(enemy.rectangle)){
                isPlayerColided = true;
            }
            if(isPlayerColided == true){
                player.setHp(player.getHp()-1);
                enemy.setHp(0);
                if(isGameOver == false && player.getHp() < 1) {
                    JOptionPane.showMessageDialog(frame, "you lost");
                    player.setDefaultValues();
                    gameState = 1;
                    isGameOver = true;
                    isPlayerColided = false;
                    keyReader.uPressed = false;
                    keyReader.downPressed = false;
                    keyReader.leftPressed = false;
                    keyReader.rightPressed = false;
                    keyReader.shoot = false;
                }
            }
        }
        for (Bullet bullet:bullets){
            for(Enemy enemy : enemies){
                if(bullet.rectangle.intersects(enemy.rectangle)){
                    if(enemy.getHp()<1){
                        killCount++;
                        cash = cash + 20;
                        enemiesToRemove.add(enemy);
                        bulletsToRemove.add(bullet);
                    }
                    else {
                        bulletsToRemove.add(bullet);
                        System.out.println(bullet.getCaliber()+ " bukket");
                        enemy.setHp(enemy.getHp() - bullet.getCaliber());
                        System.out.println(enemy.getHp());
                    }
                }
            }
        }
    }
    public void spawnInterval(){
        startCount ++;
        if(startCount == spawnRate){
            initializeEnemy();
            startCount = 0;
        }
    }
    public void showHighKillCount(){
        if (killCount > highKillCount){
            highKillCount = killCount;
        }
    }
    public int getSpawnRate() {
        return spawnRate;
    }
    public void setSpawnRate(int spawnRate) {
        this.spawnRate = spawnRate;
    }
}
