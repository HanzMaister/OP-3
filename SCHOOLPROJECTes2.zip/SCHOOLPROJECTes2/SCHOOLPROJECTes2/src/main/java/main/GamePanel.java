package main;

import objects.*;

import javax.swing.*;
import java.awt.*;


public class GamePanel extends JPanel implements Runnable{


    public int width = 600, height = 800;
    BackGround backGround;

    // loop variables
    Game game = new Game();
    Thread gamethread;
    private Font font = new Font("Aptos", Font.BOLD,22 );
    GameLogic logic = new GameLogic();

    public GamePanel(){
        setPreferredSize(new Dimension(width, height));
        setBackground(Color.black);
        setDoubleBuffered(true);
        backGround = new BackGround(this);
        addKeyListener(logic.keyReader);
        addMouseListener(logic.keyReader);
        setFocusable(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if(logic.gameState == 2){

            backGround.draw(g);
            logic.player.draw(g);
            g.setFont(font);
            g.setColor(Color.WHITE);
            g.drawString("Cash: $"+ Integer.toString(logic.cash),450,80);
            g.drawString("You killed: " + Integer.toString(logic.killCount), 450, 50);


            for (Enemy enemy : logic.enemies){
                enemy.draw(g);
            }
            for(Bullet bullet : logic.bullets){
                bullet.draw(g);
            }
        }
        else if (logic.gameState == 1){
            backGround.draw(g);
            g.setFont(font);
            g.setColor(Color.WHITE);
            g.drawString("PRESS ENTER TO START GAME ", 160,400);
            g.drawString("Highest killcount: " + Integer.toString(logic.highKillCount), 160, 500 );
            logic.setLayout();
        }
        else if(logic.gameState == 3){
            logic.shop.draw(g);
        }
    }
    public void startGameThread(){
        gamethread = new Thread(this);
        gamethread.start();
    }
    @Override
    public void run() {
        int fps = 60;
        double drawInterval = 1000000000/fps;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;

        while (gamethread != null){
            currentTime = System.nanoTime();
            delta += (currentTime - lastTime)/drawInterval;
            lastTime = currentTime;

            if(delta >= 1){
                logic.update();
                repaint();
                delta--;
            }
        }
    }
}
