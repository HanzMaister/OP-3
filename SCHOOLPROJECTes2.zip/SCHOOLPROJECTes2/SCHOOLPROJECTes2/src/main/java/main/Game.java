package main;

import objects.Shop;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Game implements KeyListener, MouseListener{
    GameLogic logic;
    Shop shop = new Shop();
    //Key values
    public boolean uPressed, downPressed, leftPressed, rightPressed,shoot,increaseCaliber, changeState, enterShop;
    public int buy = 0;
    //mouse values
    public boolean clicked = false;
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_W){
            uPressed = true;
        }
        else if(e.getKeyCode() == KeyEvent.VK_S){
            downPressed = true;
        }
        else if(e.getKeyCode() == KeyEvent.VK_A){
            leftPressed = true;
        }
        else if(e.getKeyCode() == KeyEvent.VK_D){
            rightPressed = true;
        }
        else if(e.getKeyCode() == KeyEvent.VK_SPACE){
            shoot = true;
        }
        else if(e.getKeyCode() == KeyEvent.VK_R){
            increaseCaliber = true;
        }
        else if (e.getKeyCode() == KeyEvent.VK_ENTER){
            changeState = true;
        }
        else if(e.getKeyCode()== KeyEvent.VK_E){
            enterShop = true;
        }
    }
    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_W){
            uPressed = false;
        }
        else if(e.getKeyCode() == KeyEvent.VK_S){
            downPressed = false;
        }
        else if(e.getKeyCode() == KeyEvent.VK_A){
            leftPressed = false;
        }
        else if(e.getKeyCode() == KeyEvent.VK_D){
            rightPressed = false;
        }
        else if(e.getKeyCode() == KeyEvent.VK_SPACE){
            shoot = false;
        }
        else if(e.getKeyCode() == KeyEvent.VK_R){
            increaseCaliber = false;
        }
        else if (e.getKeyCode() == KeyEvent.VK_ENTER){
            changeState = false;
        }
        else if(e.getKeyCode()== KeyEvent.VK_E){
            enterShop = false;
        }
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        if(shop.getSolid1().contains(e.getPoint())){
            buy = 1;
            System.out.println("lpp");
        }
        if(shop.getSolid2().contains(e.getPoint())){
            buy = 2;
        }
        if(shop.getSolid3().contains(e.getPoint())){
            buy = 3;
        }
        if(shop.getSolid4().contains(e.getPoint())){
            buy = 4;
        }
    }
    @Override
    public void mousePressed(MouseEvent e) {
    }
    @Override
    public void mouseReleased(MouseEvent e) {
    }
    @Override
    public void mouseEntered(MouseEvent e) {
    }
    @Override
    public void mouseExited(MouseEvent e) {
    }

}
