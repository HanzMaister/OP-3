package objects;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

public class Enemy {
    public int x;
    public int y;
    public int width = 64;
    public int height = 64;
    public int speed = 8;
    int level = 1;
    int defaultHp = 3;
    int hp = 1;
    public BufferedImage image1, image2, image3;
    public Rectangle rectangle;
    public Enemy(){
        setDefaultValues();
        getImage();
    }
    public void setDefaultValues(){
        Random random = new Random();
        x = random.nextInt(600);
        y = 0;
        level = getLevel();
        hp = getHp();

    }

    public void updatePosition(){
        y += speed;
        rectangle = new Rectangle(x , y -20, width, height);
    }
    public void getImage(){
        try {
            image1 = ImageIO.read(getClass().getResourceAsStream("/object/meteorite.png"));
            image2 = ImageIO.read(getClass().getResourceAsStream("/object/meteorite2.png"));
            image3 = ImageIO.read(getClass().getResourceAsStream("/object/meteorite3.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public void draw(Graphics g){
        if(level == 1){
            g.drawImage(image1,x,y,width,height, null);
        }
        else if(level == 2){
            g.drawImage(image2,x,y,width,height, null);
        }
        else if(level == 3){
            g.drawImage(image3,x,y,width,height, null);
        }

    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getDefaultHp() {
        return defaultHp;
    }

    public void setDefaultHp(int defaultHp) {
        this.defaultHp = defaultHp;
    }
}
