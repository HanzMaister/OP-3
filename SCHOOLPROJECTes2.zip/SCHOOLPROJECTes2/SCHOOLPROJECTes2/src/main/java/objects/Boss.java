package objects;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Boss {
    public int x;
    public int y;
    public int stopY = 64;
    public int width = 512;
    public int height = 128;
    public int speed = 1;
    int level = 1;
    int defaultHp = 20;
    int hp;

    public BufferedImage image;
    public Rectangle rectangle;

    public Boss(){
        setDefaultValues();
    }
    public void setDefaultValues(){
        int x = 0;
        int y = 0;
    }
    public void move(){
        if(y < stopY){
            y += speed;
        }
    }
    public void loadImage(){
        
    }

}
