package objects;

import main.Game;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Player {
    public int x;
    public int   y;
    public int width = 64;
    public int height = 64;
    public int defaultSpeed = 6;
    public int speed;


    public int hp = 3;
    public BufferedImage rocket1, rocket2;
    int level = 1;
    public Rectangle solidRect;
    Game keyReader;

    public Player( Game keyReader){
        getImage();
        this.keyReader = keyReader;
        setDefaultValues();
    }

    public void setDefaultValues(){
        x = 250;
        y = 550;
        hp = 3;
        speed = level * defaultSpeed;
    }
    public void update(){
        if(keyReader.uPressed) {
            y -= speed;
        }
        if(keyReader.downPressed) {
            y += speed;
        }
        if(keyReader.leftPressed){
            x -= speed;
        }
        if(keyReader.rightPressed){
            x += speed;
        }
        solidRect = new Rectangle(x + 20, y + 20,  width -40, height - 10 );
    }
    public void getImage(){
        try {
            rocket1 = ImageIO.read(getClass().getResourceAsStream("/object/Rocket.png"));
            rocket2 = ImageIO.read(getClass().getResourceAsStream("/object/rocket2.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void draw (Graphics g){
        if(level == 1){
            g.drawImage(rocket1, x, y, width, height, null);
        }
        if(level == 2){
            g.drawImage(rocket2, x, y, width, height, null);
        }

    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
